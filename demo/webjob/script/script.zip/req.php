<?php
    $result = file_get_contents('http://requestb.in/171fsky1');
    echo $result;
?>